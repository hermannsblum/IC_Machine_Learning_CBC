function [predictions] = testTrees(T,x2)
    predictions = decide_by_score(T,x2);

end